var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// wasm/index.mjs
var wasm_exports = {};
__export(wasm_exports, {
  Features: () => Features,
  browserslistToTargets: () => browserslistToTargets,
  bundle: () => bundle,
  bundleAsync: () => bundleAsync,
  composeVisitors: () => composeVisitors,
  default: () => init,
  transform: () => transform,
  transformStyleAttribute: () => transformStyleAttribute
});
module.exports = __toCommonJS(wasm_exports);

// wasm/import.meta.url-polyfill.js
var import_meta_url = typeof document === "undefined" ? new (require("url".replace("", ""))).URL("file:" + __filename).href : document.currentScript && document.currentScript.src || new URL("main.js", document.baseURI).href;

// wasm/index.mjs
var import_napi_wasm = require("napi-wasm");

// wasm/async.mjs
var cur_await_promise_sync;
function await_promise_sync(promise_addr, result_addr, error_addr) {
  cur_await_promise_sync(promise_addr, result_addr, error_addr);
}
var State = {
  None: 0,
  Unwinding: 1,
  Rewinding: 2
};
function createBundleAsync(env) {
  let { instance, exports: exports2 } = env;
  let { asyncify_get_state, asyncify_start_unwind, asyncify_stop_unwind, asyncify_start_rewind, asyncify_stop_rewind } = instance.exports;
  let DATA_ADDR = instance.exports.napi_wasm_malloc(8 + 4096);
  let DATA_START = DATA_ADDR + 8;
  let DATA_END = DATA_ADDR + 8 + 4096;
  new Int32Array(env.memory.buffer, DATA_ADDR).set([DATA_START, DATA_END]);
  function assertNoneState() {
    if (asyncify_get_state() !== State.None) {
      throw new Error(`Invalid async state ${asyncify_get_state()}, expected 0.`);
    }
  }
  let promise, result, error;
  cur_await_promise_sync = (promise_addr, result_addr, error_addr) => {
    let state = asyncify_get_state();
    if (state === State.Rewinding) {
      asyncify_stop_rewind();
      if (result != null) {
        env.createValue(result, result_addr);
      }
      if (error != null) {
        env.createValue(error, error_addr);
      }
      promise = result = error = null;
      return;
    }
    assertNoneState();
    promise = env.get(promise_addr);
    asyncify_start_unwind(DATA_ADDR);
  };
  return async function bundleAsync2(options) {
    assertNoneState();
    let res = exports2.bundle(options);
    while (asyncify_get_state() === State.Unwinding) {
      asyncify_stop_unwind();
      try {
        result = await promise;
      } catch (err) {
        error = err;
      }
      assertNoneState();
      asyncify_start_rewind(DATA_ADDR);
      res = exports2.bundle(options);
    }
    assertNoneState();
    return res;
  };
}

// wasm/browserslistToTargets.js
var BROWSER_MAPPING = {
  and_chr: "chrome",
  and_ff: "firefox",
  ie_mob: "ie",
  op_mob: "opera",
  and_qq: null,
  and_uc: null,
  baidu: null,
  bb: null,
  kaios: null,
  op_mini: null
};
function browserslistToTargets(browserslist) {
  let targets = {};
  for (let browser of browserslist) {
    let [name, v] = browser.split(" ");
    if (BROWSER_MAPPING[name] === null) {
      continue;
    }
    let version = parseVersion(v);
    if (version == null) {
      continue;
    }
    if (targets[name] == null || version < targets[name]) {
      targets[name] = version;
    }
  }
  return targets;
}
function parseVersion(version) {
  let [major, minor = 0, patch = 0] = version.split("-")[0].split(".").map((v) => parseInt(v, 10));
  if (isNaN(major) || isNaN(minor) || isNaN(patch)) {
    return null;
  }
  return major << 16 | minor << 8 | patch;
}

// wasm/flags.js
var Features = {
  Nesting: 1,
  NotSelectorList: 2,
  DirSelector: 4,
  LangSelectorList: 8,
  IsSelector: 16,
  TextDecorationThicknessPercent: 32,
  MediaIntervalSyntax: 64,
  MediaRangeSyntax: 128,
  CustomMediaQueries: 256,
  ClampFunction: 512,
  ColorFunction: 1024,
  OklabColors: 2048,
  LabColors: 4096,
  P3Colors: 8192,
  HexAlphaColors: 16384,
  SpaceSeparatedColorNotation: 32768,
  FontFamilySystemUi: 65536,
  DoublePositionGradients: 131072,
  VendorPrefixes: 262144,
  LogicalProperties: 524288,
  LightDark: 1048576,
  Selectors: 31,
  MediaQueries: 448,
  Colors: 1113088
};

// wasm/composeVisitors.js
function composeVisitors(visitors) {
  if (visitors.length === 1) {
    return visitors[0];
  }
  if (visitors.some((v) => typeof v === "function")) {
    return (opts) => {
      let v = visitors.map((v2) => typeof v2 === "function" ? v2(opts) : v2);
      return composeVisitors(v);
    };
  }
  let res = {};
  composeSimpleVisitors(res, visitors, "StyleSheet");
  composeSimpleVisitors(res, visitors, "StyleSheetExit");
  composeObjectVisitors(res, visitors, "Rule", ruleVisitor, wrapCustomAndUnknownAtRule);
  composeObjectVisitors(res, visitors, "RuleExit", ruleVisitor, wrapCustomAndUnknownAtRule);
  composeObjectVisitors(res, visitors, "Declaration", declarationVisitor, wrapCustomProperty);
  composeObjectVisitors(res, visitors, "DeclarationExit", declarationVisitor, wrapCustomProperty);
  composeSimpleVisitors(res, visitors, "Url");
  composeSimpleVisitors(res, visitors, "Color");
  composeSimpleVisitors(res, visitors, "Image");
  composeSimpleVisitors(res, visitors, "ImageExit");
  composeSimpleVisitors(res, visitors, "Length");
  composeSimpleVisitors(res, visitors, "Angle");
  composeSimpleVisitors(res, visitors, "Ratio");
  composeSimpleVisitors(res, visitors, "Resolution");
  composeSimpleVisitors(res, visitors, "Time");
  composeSimpleVisitors(res, visitors, "CustomIdent");
  composeSimpleVisitors(res, visitors, "DashedIdent");
  composeArrayFunctions(res, visitors, "MediaQuery");
  composeArrayFunctions(res, visitors, "MediaQueryExit");
  composeSimpleVisitors(res, visitors, "SupportsCondition");
  composeSimpleVisitors(res, visitors, "SupportsConditionExit");
  composeArrayFunctions(res, visitors, "Selector");
  composeTokenVisitors(res, visitors, "Token", "token", false);
  composeTokenVisitors(res, visitors, "Function", "function", false);
  composeTokenVisitors(res, visitors, "FunctionExit", "function", true);
  composeTokenVisitors(res, visitors, "Variable", "var", false);
  composeTokenVisitors(res, visitors, "VariableExit", "var", true);
  composeTokenVisitors(res, visitors, "EnvironmentVariable", "env", false);
  composeTokenVisitors(res, visitors, "EnvironmentVariableExit", "env", true);
  return res;
}
function wrapCustomAndUnknownAtRule(k, f) {
  if (k === "unknown") {
    return (value) => f({ type: "unknown", value });
  }
  if (k === "custom") {
    return (value) => f({ type: "custom", value });
  }
  return f;
}
function wrapCustomProperty(k, f) {
  return k === "custom" ? (value) => f({ property: "custom", value }) : f;
}
function ruleVisitor(f, item) {
  if (typeof f === "object") {
    if (item.type === "unknown") {
      let v = f.unknown;
      if (typeof v === "object") {
        v = v[item.value.name];
      }
      return v?.(item.value);
    }
    if (item.type === "custom") {
      let v = f.custom;
      if (typeof v === "object") {
        v = v[item.value.name];
      }
      return v?.(item.value);
    }
    return f[item.type]?.(item);
  }
  return f?.(item);
}
function declarationVisitor(f, item) {
  if (typeof f === "object") {
    let name = item.property;
    if (item.property === "unparsed") {
      name = item.value.propertyId.property;
    } else if (item.property === "custom") {
      let v = f.custom;
      if (typeof v === "object") {
        v = v[item.value.name];
      }
      return v?.(item.value);
    }
    return f[name]?.(item);
  }
  return f?.(item);
}
function extractObjectsOrFunctions(visitors, key) {
  let values = [];
  let hasFunction = false;
  let allKeys = /* @__PURE__ */ new Set();
  for (let visitor of visitors) {
    let v = visitor[key];
    if (v) {
      if (typeof v === "function") {
        hasFunction = true;
      } else {
        for (let key2 in v) {
          allKeys.add(key2);
        }
      }
      values.push(v);
    }
  }
  return [values, hasFunction, allKeys];
}
function composeObjectVisitors(res, visitors, key, apply, wrapKey) {
  let [values, hasFunction, allKeys] = extractObjectsOrFunctions(visitors, key);
  if (values.length === 0) {
    return;
  }
  if (values.length === 1) {
    res[key] = values[0];
    return;
  }
  let f = createArrayVisitor(visitors, (visitor, item) => apply(visitor[key], item));
  if (hasFunction) {
    res[key] = f;
  } else {
    let v = {};
    for (let k of allKeys) {
      v[k] = wrapKey(k, f);
    }
    res[key] = v;
  }
}
function composeTokenVisitors(res, visitors, key, type, isExit) {
  let [values, hasFunction, allKeys] = extractObjectsOrFunctions(visitors, key);
  if (values.length === 0) {
    return;
  }
  if (values.length === 1) {
    res[key] = values[0];
    return;
  }
  let f = createTokenVisitor(visitors, type, isExit);
  if (hasFunction) {
    res[key] = f;
  } else {
    let v = {};
    for (let key2 of allKeys) {
      v[key2] = f;
    }
    res[key] = v;
  }
}
function createTokenVisitor(visitors, type, isExit) {
  let v = createArrayVisitor(visitors, (visitor, item) => {
    let f;
    switch (item.type) {
      case "token":
        f = visitor.Token;
        if (typeof f === "object") {
          f = f[item.value.type];
        }
        break;
      case "function":
        f = isExit ? visitor.FunctionExit : visitor.Function;
        if (typeof f === "object") {
          f = f[item.value.name];
        }
        break;
      case "var":
        f = isExit ? visitor.VariableExit : visitor.Variable;
        break;
      case "env":
        f = isExit ? visitor.EnvironmentVariableExit : visitor.EnvironmentVariable;
        if (typeof f === "object") {
          let name;
          switch (item.value.name.type) {
            case "ua":
            case "unknown":
              name = item.value.name.value;
              break;
            case "custom":
              name = item.value.name.ident;
              break;
          }
          f = f[name];
        }
        break;
      case "color":
        f = visitor.Color;
        break;
      case "url":
        f = visitor.Url;
        break;
      case "length":
        f = visitor.Length;
        break;
      case "angle":
        f = visitor.Angle;
        break;
      case "time":
        f = visitor.Time;
        break;
      case "resolution":
        f = visitor.Resolution;
        break;
      case "dashed-ident":
        f = visitor.DashedIdent;
        break;
    }
    if (!f) {
      return;
    }
    let res = f(item.value);
    switch (item.type) {
      case "color":
      case "url":
      case "length":
      case "angle":
      case "time":
      case "resolution":
      case "dashed-ident":
        if (Array.isArray(res)) {
          res = res.map((value) => ({ type: item.type, value }));
        } else if (res) {
          res = { type: item.type, value: res };
        }
        break;
    }
    return res;
  });
  return (value) => v({ type, value });
}
function extractFunctions(visitors, key) {
  let functions = [];
  for (let visitor of visitors) {
    let f = visitor[key];
    if (f) {
      functions.push(f);
    }
  }
  return functions;
}
function composeSimpleVisitors(res, visitors, key) {
  let functions = extractFunctions(visitors, key);
  if (functions.length === 0) {
    return;
  }
  if (functions.length === 1) {
    res[key] = functions[0];
    return;
  }
  res[key] = (arg) => {
    let mutated = false;
    for (let f of functions) {
      let res2 = f(arg);
      if (res2) {
        arg = res2;
        mutated = true;
      }
    }
    return mutated ? arg : void 0;
  };
}
function composeArrayFunctions(res, visitors, key) {
  let functions = extractFunctions(visitors, key);
  if (functions.length === 0) {
    return;
  }
  if (functions.length === 1) {
    res[key] = functions[0];
    return;
  }
  res[key] = createArrayVisitor(functions, (f, item) => f(item));
}
function createArrayVisitor(visitors, apply) {
  let seen = new Bitset(visitors.length);
  return (arg) => {
    let arr = [arg];
    let mutated = false;
    seen.clear();
    for (let i = 0; i < arr.length; i++) {
      for (let v = 0; v < visitors.length && i < arr.length; ) {
        if (seen.get(v)) {
          v++;
          continue;
        }
        let item = arr[i];
        let visitor = visitors[v];
        let res = apply(visitor, item);
        if (Array.isArray(res)) {
          if (res.length === 0) {
            arr.splice(i, 1);
          } else if (res.length === 1) {
            arr[i] = res[0];
          } else {
            arr.splice(i, 1, ...res);
          }
          mutated = true;
          seen.set(v);
          v = 0;
        } else if (res) {
          arr[i] = res;
          mutated = true;
          seen.set(v);
          v = 0;
        } else {
          v++;
        }
      }
    }
    if (!mutated) {
      return;
    }
    return arr.length === 1 ? arr[0] : arr;
  };
}
var Bitset = class {
  constructor(maxBits = 32) {
    this.bits = 0;
    this.more = maxBits > 32 ? new Uint32Array(Math.ceil((maxBits - 32) / 32)) : null;
  }
  /** @param {number} bit */
  get(bit) {
    if (bit >= 32 && this.more) {
      let i = Math.floor((bit - 32) / 32);
      let b = bit % 32;
      return Boolean(this.more[i] & 1 << b);
    } else {
      return Boolean(this.bits & 1 << bit);
    }
  }
  /** @param {number} bit */
  set(bit) {
    if (bit >= 32 && this.more) {
      let i = Math.floor((bit - 32) / 32);
      let b = bit % 32;
      this.more[i] |= 1 << b;
    } else {
      this.bits |= 1 << bit;
    }
  }
  clear() {
    this.bits = 0;
    if (this.more) {
      this.more.fill(0);
    }
  }
};

// wasm/index.mjs
var wasm;
var initPromise;
var bundleAsyncInternal;
async function init(input) {
  if (wasm)
    return;
  if (initPromise) {
    await initPromise;
    return;
  }
  input = input ?? new URL("lightningcss_node.wasm", import_meta_url);
  if (typeof input === "string" || typeof Request === "function" && input instanceof Request || typeof URL === "function" && input instanceof URL) {
    input = fetchOrReadFromFs(input);
  }
  let env;
  initPromise = input.then((input2) => load(input2, {
    env: {
      ...import_napi_wasm.napi,
      await_promise_sync,
      __getrandom_v03_custom: (ptr, len) => {
        let buf = env.memory.subarray(ptr, ptr + len);
        crypto.getRandomValues(buf);
      }
    }
  })).then(({ instance }) => {
    instance.exports.register_module();
    env = new import_napi_wasm.Environment(instance);
    bundleAsyncInternal = createBundleAsync(env);
    wasm = env.exports;
  });
  await initPromise;
}
function transform(options) {
  return wrap(wasm.transform, options);
}
function transformStyleAttribute(options) {
  return wrap(wasm.transformStyleAttribute, options);
}
function bundle(options) {
  return wrap(wasm.bundle, options);
}
function bundleAsync(options) {
  return wrap(bundleAsyncInternal, options);
}
function wrap(call, options) {
  if (typeof options.visitor === "function") {
    let deps = [];
    options.visitor = options.visitor({
      addDependency(dep) {
        deps.push(dep);
      }
    });
    let result = call(options);
    if (result instanceof Promise) {
      result = result.then((res) => {
        if (deps.length) {
          res.dependencies ??= [];
          res.dependencies.push(...deps);
        }
        return res;
      });
    } else if (deps.length) {
      result.dependencies ??= [];
      result.dependencies.push(...deps);
    }
    return result;
  } else {
    return call(options);
  }
}
async function load(module2, imports) {
  if (typeof Response === "function" && module2 instanceof Response) {
    if (typeof WebAssembly.instantiateStreaming === "function") {
      try {
        return await WebAssembly.instantiateStreaming(module2, imports);
      } catch (e) {
        if (module2.headers.get("Content-Type") != "application/wasm") {
          console.warn("`WebAssembly.instantiateStreaming` failed because your server does not serve wasm with `application/wasm` MIME type. Falling back to `WebAssembly.instantiate` which is slower. Original error:\n", e);
        } else {
          throw e;
        }
      }
    }
    const bytes = await module2.arrayBuffer();
    return await WebAssembly.instantiate(bytes, imports);
  } else {
    const instance = await WebAssembly.instantiate(module2, imports);
    if (instance instanceof WebAssembly.Instance) {
      return { instance, module: module2 };
    } else {
      return instance;
    }
  }
}
async function fetchOrReadFromFs(inputPath) {
  try {
    const fs = await import("fs");
    return fs.readFileSync(inputPath);
  } catch {
    return fetch(inputPath);
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  Features,
  browserslistToTargets,
  bundle,
  bundleAsync,
  composeVisitors,
  transform,
  transformStyleAttribute
});
